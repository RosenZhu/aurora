var searchData=
[
  ['native_5ffd',['NATIVE_FD',['../group__OS__APIS__TYPES.html#gaeb77513b3223d163064c7b1f5e38e8c3',1,'types.h']]],
  ['native_5fpid',['NATIVE_PID',['../group__OS__APIS__TYPES.html#gae6c37d3a178129452bbb6e591c13aeb0',1,'types.h']]],
  ['native_5ftid',['NATIVE_TID',['../group__OS__APIS__TYPES.html#ga20167a3cedec6512ccdc030b50ee780b',1,'types.h']]]
];
