var searchData=
[
  ['os_5fapis_5frw_5flock_5fimpl_5ft',['OS_APIS_RW_LOCK_IMPL_T',['../structOS__APIS__RW__LOCK__IMPL__T.html',1,'']]],
  ['os_5fmemory_5fat_5faddr_5finformation',['OS_MEMORY_AT_ADDR_INFORMATION',['../structOS__MEMORY__AT__ADDR__INFORMATION.html',1,'']]]
];
