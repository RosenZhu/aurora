var searchData=
[
  ['generic_5ferr',['generic_err',['../struct__OS__RETURN__CODE.html#a45784e2e0ca326e8575095f5c21ebd84',1,'_OS_RETURN_CODE']]],
  ['generic_20error_20codes',['Generic error codes',['../group__OS__APIS__DEF.html',1,'']]]
];
