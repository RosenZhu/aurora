var searchData=
[
  ['baseaddress',['BaseAddress',['../structOS__MEMORY__AT__ADDR__INFORMATION.html#aa5d95428913abff4a7c0e5f3e46fd637',1,'OS_MEMORY_AT_ADDR_INFORMATION']]],
  ['bool_5ft',['BOOL_T',['../group__OS__APIS__TYPES.html#gad312c486942310e24394e7ea81f8f7e1',1,'types.h']]]
];
