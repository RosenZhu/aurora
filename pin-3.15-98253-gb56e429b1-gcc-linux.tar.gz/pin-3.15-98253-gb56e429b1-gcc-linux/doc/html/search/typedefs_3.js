var searchData=
[
  ['exception_5finfo',['EXCEPTION_INFO',['../group__EXCEPTION__API.html#ga6b419bb0f9a400c889e4cf12db70dda1',1,'LEVEL_BASE']]]
];
