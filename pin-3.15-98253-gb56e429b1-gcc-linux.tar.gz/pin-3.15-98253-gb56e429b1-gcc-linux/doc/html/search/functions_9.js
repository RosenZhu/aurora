var searchData=
[
  ['knob_5fbase',['KNOB_BASE',['../group__KNOB__BASIC.html#ga8cfecffd328b63853fbd7534d9b07dc9',1,'LEVEL_BASE::KNOB_BASE']]]
];
