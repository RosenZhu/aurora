var searchData=
[
  ['bbl_3a_20single_20entrance_2c_20single_20exit_20sequence_20of_20instructions',['BBL: Single entrance, single exit sequence of instructions',['../group__BBL__BASIC__API.html',1,'']]],
  ['basic_20types',['Basic types',['../group__TYPE__BASE.html',1,'']]]
];
