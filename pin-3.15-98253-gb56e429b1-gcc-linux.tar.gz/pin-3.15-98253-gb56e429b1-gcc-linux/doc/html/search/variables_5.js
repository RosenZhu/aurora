var searchData=
[
  ['reg_5ffirstinregset',['REG_FirstInRegset',['../group__REG__CPU__IA32.html#ga106d11b76262e7d9efa0cce801cf8431',1,'LEVEL_CORE']]],
  ['reg_5flastinregset',['REG_LastInRegset',['../group__REG__CPU__IA32.html#gac3c3f8a822d40e53bc8c599368eb9a44',1,'LEVEL_CORE']]],
  ['regcbit_5fall_5fregs',['REGCBIT_ALL_REGS',['../group__REG__CPU__IA32.html#ga3dbb64324ec7e6cf592b3a007d637e41',1,'LEVEL_BASE']]],
  ['regcbit_5fapp_5fall',['REGCBIT_APP_ALL',['../group__REG__CPU__IA32.html#gafef963c990ff2998f8a62044ca08f5af',1,'LEVEL_BASE']]],
  ['regcbit_5fapp_5fflags',['REGCBIT_APP_FLAGS',['../group__REG__CPU__IA32.html#ga797c94104721a4d10c3375d92f8a977a',1,'LEVEL_BASE']]],
  ['regcbit_5fpartial',['REGCBIT_PARTIAL',['../group__REG__CPU__IA32.html#gadaec9333a54cfb71118ad03996943c69',1,'LEVEL_BASE']]],
  ['regcbit_5fpin_5fall',['REGCBIT_PIN_ALL',['../group__REG__CPU__IA32.html#ga0003ddbd5a31411cef15fe6adc6a1bf4',1,'LEVEL_BASE']]],
  ['regcbit_5fpin_5fflags',['REGCBIT_PIN_FLAGS',['../group__REG__CPU__IA32.html#ga42d784c0a1e776497acb405282fab148',1,'LEVEL_BASE']]],
  ['regsbit_5fpin_5finst_5fall',['REGSBIT_PIN_INST_ALL',['../group__REG__CPU__IA32.html#ga656d3616de3d5ae8d26f2b6252c686e3',1,'LEVEL_BASE']]],
  ['regsbit_5fpin_5fscratch_5fall',['REGSBIT_PIN_SCRATCH_ALL',['../group__REG__CPU__IA32.html#ga89097de642e222f3d0a0553464e2a584',1,'LEVEL_BASE']]],
  ['regsbit_5fstackptr_5fall',['REGSBIT_STACKPTR_ALL',['../group__REG__CPU__IA32.html#ga10bb628d479cc23033c4295ceb9e3823',1,'LEVEL_BASE']]]
];
